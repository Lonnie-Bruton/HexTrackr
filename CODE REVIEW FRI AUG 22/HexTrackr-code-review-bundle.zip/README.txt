HexTrackr Code Review Bundle
=============================

Files included:
1) HexTrackr-code-review.md  - Comprehensive, single-document code review with diagrams.
2) HexTrackr-symbol-index.csv - Cross-reference index (definitions & usages).

Tips:
- Open the Markdown in VS Code with a Mermaid extension to render the diagrams.
- Use the CSV in Excel/Sheets; filter by Name or File to jump around quickly.
