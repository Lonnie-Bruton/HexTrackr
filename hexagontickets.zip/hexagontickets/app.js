// HexTrackr - Hexagon Tickets Management System
class HexagonTicketsManager {
    constructor() {
        this.tickets = [];
        this.currentEditingId = null;
        this.sharedDocumentation = []; // Store shared documentation files
        this.sortColumn = null;
        this.sortDirection = 'asc';
        this.init();
    }

    init() {
        this.loadTickets();
        this.loadSharedDocumentation();
        this.setupEventListeners();
        this.populateLocationFilter();
        this.updateStatistics();
        this.renderTickets();
        
        // Set default date to today
        document.getElementById('dateSubmitted').value = new Date().toISOString().split('T')[0];
        
        // Set default due date to 7 days from now
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 7);
        document.getElementById('dateDue').value = dueDate.toISOString().split('T')[0];
    }

    setupEventListeners() {
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', () => {
            this.renderTickets();
        });

        // Filter functionality
        document.getElementById('statusFilter').addEventListener('change', () => {
            this.renderTickets();
        });

        document.getElementById('locationFilter').addEventListener('change', () => {
            this.renderTickets();
        });

        // Device management
        this.setupDeviceManagement();

        // Modal events
        document.getElementById('ticketModal').addEventListener('hidden.bs.modal', () => {
            this.resetForm();
        });

        // Shared documentation handling
        document.getElementById('attachDocsBtn').addEventListener('click', () => {
            document.getElementById('sharedDocsInput').click();
        });

        document.getElementById('sharedDocsInput').addEventListener('change', (e) => {
            this.handleSharedDocumentation(e.target.files);
        });

        // CSV import handling
        document.getElementById('importCsvBtn').addEventListener('click', () => {
            document.getElementById('csvImportInput').click();
        });

        document.getElementById('csvImportInput').addEventListener('change', (e) => {
            this.handleCsvImport(e.target.files[0]);
        });
    }

    setupDeviceManagement() {
        const container = document.getElementById('devicesContainer');
        
        container.addEventListener('click', (e) => {
            if (e.target.classList.contains('add-device-btn') || e.target.parentElement.classList.contains('add-device-btn')) {
                this.addDeviceField();
            } else if (e.target.classList.contains('remove-device-btn') || e.target.parentElement.classList.contains('remove-device-btn')) {
                this.removeDeviceField(e.target.closest('.device-entry'));
            }
        });
    }

    addDeviceField() {
        const container = document.getElementById('devicesContainer');
        const deviceEntry = document.createElement('div');
        deviceEntry.className = 'device-entry mb-2';
        
        // Get the value from the last device input to smart increment
        const lastInput = container.querySelector('.device-entry:last-child .device-input');
        const suggestedValue = this.generateNextDeviceName(lastInput ? lastInput.value : '');
        
        deviceEntry.innerHTML = `
            <div class="input-group">
                <input type="text" class="form-control device-input" placeholder="Enter device name (e.g., host01)" value="${suggestedValue}">
                <button type="button" class="btn btn-outline-success add-device-btn">
                    <i class="fas fa-plus"></i>
                </button>
                <button type="button" class="btn btn-outline-danger remove-device-btn">
                    <i class="fas fa-minus"></i>
                </button>
            </div>
        `;
        
        container.appendChild(deviceEntry);
        this.updateDeviceButtons();
        
        // Focus and select the new input for easy editing
        const newInput = deviceEntry.querySelector('.device-input');
        newInput.focus();
        newInput.select();
    }

    generateNextDeviceName(previousValue) {
        if (!previousValue || previousValue.trim() === '') {
            return '';
        }

        // Look for patterns like: nswan01, host30, server123, etc.
        const match = previousValue.match(/^(.+?)(\d+)$/);
        
        if (match) {
            const prefix = match[1]; // e.g., "nswan", "host", "server"
            const number = parseInt(match[2], 10); // e.g., 1, 30, 123
            const nextNumber = number + 1;
            
            // Preserve leading zeros if they exist
            const originalNumberStr = match[2];
            const paddedNumber = nextNumber.toString().padStart(originalNumberStr.length, '0');
            
            return prefix + paddedNumber;
        }
        
        // If no numeric pattern found, return empty to let user type
        return '';
    }

    removeDeviceField(deviceEntry) {
        const container = document.getElementById('devicesContainer');
        if (container.children.length > 1) {
            deviceEntry.remove();
            this.updateDeviceButtons();
        }
    }

    updateDeviceButtons() {
        const deviceEntries = document.querySelectorAll('.device-entry');
        deviceEntries.forEach((entry, index) => {
            const removeBtn = entry.querySelector('.remove-device-btn');
            if (deviceEntries.length === 1) {
                removeBtn.style.display = 'none';
            } else {
                removeBtn.style.display = 'block';
            }
        });
    }

    getDevices() {
        const deviceInputs = document.querySelectorAll('.device-input');
        const devices = [];
        deviceInputs.forEach(input => {
            if (input.value.trim()) {
                devices.push(input.value.trim());
            }
        });
        return devices;
    }

    setDevices(devices) {
        const container = document.getElementById('devicesContainer');
        container.innerHTML = '';
        
        if (devices.length === 0) {
            devices = [''];
        }
        
        devices.forEach((device, index) => {
            const deviceEntry = document.createElement('div');
            deviceEntry.className = 'device-entry mb-2';
            
            deviceEntry.innerHTML = `
                <div class="input-group">
                    <input type="text" class="form-control device-input" placeholder="Enter device name (e.g., host01)" value="${device}">
                    <button type="button" class="btn btn-outline-success add-device-btn">
                        <i class="fas fa-plus"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger remove-device-btn" ${devices.length === 1 ? 'style="display: none;"' : ''}>
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            `;
            
            container.appendChild(deviceEntry);
        });
        
        this.updateDeviceButtons();
    }

    async saveTicket() {
        // Only validate that location is required
        const location = document.getElementById('location').value.trim();
        if (!location) {
            alert('Location is required.');
            document.getElementById('location').focus();
            return;
        }

        const ticket = {
            id: this.currentEditingId || Date.now().toString(),
            dateSubmitted: document.getElementById('dateSubmitted').value,
            dateDue: document.getElementById('dateDue').value,
            hexagonTicket: document.getElementById('hexagonTicket').value,
            serviceNowTicket: document.getElementById('serviceNowTicket').value,
            location: document.getElementById('location').value,
            devices: this.getDevices(),
            supervisor: document.getElementById('supervisor').value,
            tech: document.getElementById('tech').value,
            status: document.getElementById('status').value,
            notes: document.getElementById('notes').value,
            attachments: [], // No more attachments since we removed the file input
            createdAt: this.currentEditingId ? this.getTicketById(this.currentEditingId).createdAt : new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        if (this.currentEditingId) {
            const index = this.tickets.findIndex(t => t.id === this.currentEditingId);
            this.tickets[index] = ticket;
        } else {
            this.tickets.push(ticket);
        }

        this.saveTickets();
        this.renderTickets();
        this.updateStatistics();
        this.populateLocationFilter();
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('ticketModal'));
        modal.hide();

        // Show success message
        this.showToast('Ticket saved successfully!', 'success');
    }

    editTicket(id) {
        const ticket = this.getTicketById(id);
        if (!ticket) return;

        this.currentEditingId = id;
        
        document.getElementById('dateSubmitted').value = ticket.dateSubmitted;
        document.getElementById('dateDue').value = ticket.dateDue;
        document.getElementById('hexagonTicket').value = ticket.hexagonTicket;
        document.getElementById('serviceNowTicket').value = ticket.serviceNowTicket;
        document.getElementById('location').value = ticket.location;
        document.getElementById('supervisor').value = ticket.supervisor;
        document.getElementById('tech').value = ticket.tech;
        document.getElementById('status').value = ticket.status;
        document.getElementById('notes').value = ticket.notes || '';
        
        this.setDevices(ticket.devices || []);
        
        document.getElementById('ticketModalLabel').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Ticket';
        
        const modal = new bootstrap.Modal(document.getElementById('ticketModal'));
        modal.show();
    }

    deleteTicket(id) {
        if (confirm('Are you sure you want to delete this ticket?')) {
            this.tickets = this.tickets.filter(t => t.id !== id);
            this.saveTickets();
            this.renderTickets();
            this.updateStatistics();
            this.populateLocationFilter();
            this.showToast('Ticket deleted successfully!', 'success');
        }
    }

    viewTicket(id) {
        const ticket = this.getTicketById(id);
        if (!ticket) return;

        // Generate markdown content for the ticket
        const markdownContent = this.generateMarkdown(ticket);
        
        // Display in the markdown view modal
        document.getElementById('markdownContent').textContent = markdownContent;
        document.getElementById('viewTicketModal').setAttribute('data-ticket-id', id);
        
        const modal = new bootstrap.Modal(document.getElementById('viewTicketModal'));
        modal.show();
    }

    editTicketFromView() {
        const ticketId = document.getElementById('viewTicketModal').getAttribute('data-ticket-id');
        const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewTicketModal'));
        viewModal.hide();
        
        setTimeout(() => {
            this.editTicket(ticketId);
        }, 300);
    }

    renderTickets() {
        const tbody = document.getElementById('ticketsTableBody');
        const filteredTickets = this.getFilteredTickets();

        if (filteredTickets.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="10" class="text-center py-4">
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h5>No tickets found</h5>
                            <p>No tickets match your current search criteria.</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = filteredTickets.map(ticket => {
            const isOverdue = new Date(ticket.dateDue) < new Date() && ticket.status !== 'Completed' && ticket.status !== 'Closed';
            
            return `
                <tr class="${isOverdue ? 'overdue' : ''}" data-ticket-id="${ticket.id}">
                    <td>${this.formatDate(ticket.dateSubmitted)}</td>
                    <td>${this.formatDate(ticket.dateDue)} ${isOverdue ? '<span class="badge bg-danger">OVERDUE</span>' : ''}</td>
                    <td><strong>${this.highlightSearch(ticket.hexagonTicket)}</strong></td>
                    <td>${this.highlightSearch(ticket.serviceNowTicket || 'N/A')}</td>
                    <td>${this.highlightSearch(ticket.location)}</td>
                    <td>
                        <div class="devices-list">
                            ${ticket.devices.map(device => `<span class="device-tag">${this.highlightSearch(device)}</span>`).join('')}
                        </div>
                    </td>
                    <td>${this.highlightSearch(ticket.supervisor)}</td>
                    <td>${this.highlightSearch(ticket.tech)}</td>
                    <td><span class="status-badge status-${ticket.status.toLowerCase().replace(' ', '-')}">${ticket.status}</span></td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group">
                            <button class="btn btn-outline-primary action-btn" onclick="ticketManager.viewTicket('${ticket.id}')" title="View">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-outline-warning action-btn" onclick="ticketManager.editTicket('${ticket.id}')" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline-success action-btn" onclick="ticketManager.bundleTicketFiles('${ticket.id}')" title="Download Bundle">
                                <i class="fas fa-download"></i>
                            </button>
                            <button class="btn btn-outline-danger action-btn" onclick="ticketManager.deleteTicket('${ticket.id}')" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    getFilteredTickets() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const statusFilter = document.getElementById('statusFilter').value;
        const locationFilter = document.getElementById('locationFilter').value;

        return this.tickets.filter(ticket => {
            const matchesSearch = !searchTerm || 
                ticket.hexagonTicket.toLowerCase().includes(searchTerm) ||
                ticket.serviceNowTicket.toLowerCase().includes(searchTerm) ||
                ticket.location.toLowerCase().includes(searchTerm) ||
                ticket.supervisor.toLowerCase().includes(searchTerm) ||
                ticket.tech.toLowerCase().includes(searchTerm) ||
                ticket.devices.some(device => device.toLowerCase().includes(searchTerm));

            const matchesStatus = !statusFilter || ticket.status === statusFilter;
            const matchesLocation = !locationFilter || ticket.location === locationFilter;

            return matchesSearch && matchesStatus && matchesLocation;
        });
    }

    highlightSearch(text) {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        if (!searchTerm || !text) return text;

        const regex = new RegExp(`(${searchTerm})`, 'gi');
        return text.replace(regex, '<span class="highlight">$1</span>');
    }

    updateStatistics() {
        const total = this.tickets.length;
        const open = this.tickets.filter(t => t.status === 'Open' || t.status === 'In Progress').length;
        const completed = this.tickets.filter(t => t.status === 'Completed' || t.status === 'Closed').length;
        const overdue = this.tickets.filter(t => {
            return new Date(t.dateDue) < new Date() && t.status !== 'Completed' && t.status !== 'Closed';
        }).length;

        document.getElementById('totalTickets').textContent = total;
        document.getElementById('openTickets').textContent = open;
        document.getElementById('completedTickets').textContent = completed;
        document.getElementById('overdueTickets').textContent = overdue;
    }

    populateLocationFilter() {
        const locations = [...new Set(this.tickets.map(t => t.location))].sort();
        const filter = document.getElementById('locationFilter');
        const currentValue = filter.value;
        
        filter.innerHTML = '<option value="">All Locations</option>';
        locations.forEach(location => {
            const option = document.createElement('option');
            option.value = location;
            option.textContent = location;
            filter.appendChild(option);
        });
        
        filter.value = currentValue;
    }

    resetForm() {
        document.getElementById('ticketForm').reset();
        this.currentEditingId = null;
        document.getElementById('ticketModalLabel').innerHTML = '<i class="fas fa-plus me-2"></i>Add New Ticket';
        
        // Reset dates
        document.getElementById('dateSubmitted').value = new Date().toISOString().split('T')[0];
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 7);
        document.getElementById('dateDue').value = dueDate.toISOString().split('T')[0];
        
        // Reset devices
        this.setDevices(['']);
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    getTicketById(id) {
        return this.tickets.find(t => t.id === id);
    }

    loadTickets() {
        const stored = localStorage.getItem('hexagonTickets');
        if (stored) {
            this.tickets = JSON.parse(stored);
        }
    }

    saveTickets() {
        localStorage.setItem('hexagonTickets', JSON.stringify(this.tickets));
    }

    showToast(message, type = 'info') {
        // Create toast container if it doesn't exist
        let toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toastContainer';
            toastContainer.className = 'position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '1055';
            document.body.appendChild(toastContainer);
        }

        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : type === 'error' ? 'danger' : 'info'} border-0`;
        toast.id = toastId;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;

        toastContainer.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();

        // Remove toast after it's hidden
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    // Individual Ticket PDF Download
    downloadTicketPDF(id) {
        const ticket = this.getTicketById(id);
        if (!ticket) {
            this.showToast('Ticket not found', 'error');
            return;
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('p', 'mm', 'a4');

        // Title
        doc.setFontSize(16);
        doc.setTextColor(0, 102, 204); // Blue color
        doc.text(`Hexagon Ticket [${ticket.hexagonTicket}]`, 20, 25);

        // Content styling
        doc.setTextColor(0, 0, 0); // Black color
        doc.setFontSize(12);

        let yPosition = 45;
        const lineHeight = 8;
        const sectionSpacing = 12;

        // Site/Group
        doc.setFont('helvetica', 'bold');
        doc.text('Site/Group:', 20, yPosition);
        doc.setFont('helvetica', 'normal');
        doc.text(`${ticket.location}`, 20, yPosition + lineHeight);
        yPosition += sectionSpacing;

        // Subject
        doc.setFont('helvetica', 'bold');
        doc.text('Subject:', 20, yPosition);
        doc.setFont('helvetica', 'normal');
        doc.text(`NETOPS: Software Upgrades [${ticket.location}]`, 20, yPosition + lineHeight);
        yPosition += sectionSpacing;

        // Start Date
        doc.setFont('helvetica', 'bold');
        doc.text('Start Date:', 20, yPosition);
        doc.setFont('helvetica', 'normal');
        doc.text(this.formatDate(ticket.dateSubmitted), 20, yPosition + lineHeight);
        yPosition += sectionSpacing;

        // Required Completion Date
        doc.setFont('helvetica', 'bold');
        doc.text('Required Completion Date:', 20, yPosition);
        doc.setFont('helvetica', 'normal');
        doc.text(this.formatDate(ticket.dateDue), 20, yPosition + lineHeight);
        yPosition += sectionSpacing;

        // Task Instruction
        doc.setFont('helvetica', 'bold');
        doc.text('Task Instruction:', 20, yPosition);
        yPosition += lineHeight;
        doc.setFont('helvetica', 'normal');
        
        const taskText = `There are critical security patches that must be applied within 30 days at the [${ticket.location}] site.`;
        const splitTaskText = doc.splitTextToSize(taskText, 170);
        doc.text(splitTaskText, 20, yPosition);
        yPosition += splitTaskText.length * 6 + 8;

        // Instructions with Service Now info
        const instructionText = `Please schedule a maintenance outage of at least two hours and contact the ITCC @ 918-732-4822 with service now ticket number [${ticket.serviceNowTicket || 'TBD'}] to coordinate Netops to apply security updates and reboot the equipment.`;
        const splitInstructionText = doc.splitTextToSize(instructionText, 170);
        doc.text(splitInstructionText, 20, yPosition);
        yPosition += splitInstructionText.length * 6 + 15;

        // Devices section
        doc.setFont('helvetica', 'bold');
        doc.text('The devices will be updated and rebooted in the following order:', 20, yPosition);
        yPosition += lineHeight + 5;

        doc.setFont('helvetica', 'normal');
        ticket.devices.forEach((device, index) => {
            doc.text(`${index + 1}. ${device}`, 30, yPosition);
            yPosition += lineHeight;
        });

        // Notes section (moved up)
        if (ticket.notes) {
            yPosition += 15;
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text('Notes:', 20, yPosition);
            yPosition += 8;
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(10);
            const splitNotes = doc.splitTextToSize(ticket.notes, 170);
            doc.text(splitNotes, 20, yPosition);
            yPosition += splitNotes.length * 6;
        }

        // Add shared documentation info if available
        if (this.sharedDocumentation.length > 0) {
            yPosition += 15;
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(12);
            doc.setTextColor(0, 0, 0);
            doc.text('Attached Documentation:', 20, yPosition);
            yPosition += 8;
            
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(10);
            this.sharedDocumentation.forEach((doc_file, index) => {
                doc.text(`${index + 1}. ${doc_file.name} (${this.formatFileSize(doc_file.size)})`, 25, yPosition);
                yPosition += 6;
            });
            yPosition += 5;
        }

        // Footer with additional details
        yPosition += 20;
        doc.setFontSize(10);
        doc.setTextColor(100, 100, 100);
        doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, yPosition);
        doc.text(`Supervisor: ${ticket.supervisor}`, 20, yPosition + 6);
        doc.text(`Tech: ${ticket.tech}`, 20, yPosition + 12);
        doc.text(`Status: ${ticket.status}`, 20, yPosition + 18);

        // Generate filename: sitename_date_ticketnumber
        const siteName = ticket.location.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '');
        const dateStr = ticket.dateSubmitted.replace(/-/g, '');
        const ticketNum = ticket.hexagonTicket.replace(/[^a-zA-Z0-9]/g, '');
        const filename = `${siteName}_${dateStr}_${ticketNum}.pdf`;

        // Save the PDF
        doc.save(filename);
        this.showToast(`PDF downloaded: ${filename}`, 'success');
    }

    // File conversion helper
    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }

    // Bundle ticket files into zip
    async bundleTicketFiles(id) {
        const ticket = this.getTicketById(id);
        if (!ticket) {
            this.showToast('Ticket not found', 'error');
            return;
        }

        try {
            const zip = new JSZip();

            // Generate the PDF content
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('p', 'mm', 'a4');

            // Title
            doc.setFontSize(16);
            doc.setTextColor(0, 102, 204);
            doc.text(`Hexagon Ticket [${ticket.hexagonTicket}]`, 20, 25);

            // Content styling
            doc.setTextColor(0, 0, 0);
            doc.setFontSize(12);

            let yPosition = 45;
            const lineHeight = 8;
            const sectionSpacing = 12;

            // Site/Group
            doc.setFont('helvetica', 'bold');
            doc.text('Site/Group:', 20, yPosition);
            doc.setFont('helvetica', 'normal');
            doc.text(`${ticket.location}`, 20, yPosition + lineHeight);
            yPosition += sectionSpacing;

            // Subject
            doc.setFont('helvetica', 'bold');
            doc.text('Subject:', 20, yPosition);
            doc.setFont('helvetica', 'normal');
            doc.text(`NETOPS: Software Upgrades [${ticket.location}]`, 20, yPosition + lineHeight);
            yPosition += sectionSpacing;

            // Start Date
            doc.setFont('helvetica', 'bold');
            doc.text('Start Date:', 20, yPosition);
            doc.setFont('helvetica', 'normal');
            doc.text(this.formatDate(ticket.dateSubmitted), 20, yPosition + lineHeight);
            yPosition += sectionSpacing;

            // Required Completion Date
            doc.setFont('helvetica', 'bold');
            doc.text('Required Completion Date:', 20, yPosition);
            doc.setFont('helvetica', 'normal');
            doc.text(this.formatDate(ticket.dateDue), 20, yPosition + lineHeight);
            yPosition += sectionSpacing;

            // Task Instruction
            doc.setFont('helvetica', 'bold');
            doc.text('Task Instruction:', 20, yPosition);
            yPosition += lineHeight;
            doc.setFont('helvetica', 'normal');
            
            const taskText = `There are critical security patches that must be applied within 30 days at the [${ticket.location}] site.`;
            const splitTaskText = doc.splitTextToSize(taskText, 170);
            doc.text(splitTaskText, 20, yPosition);
            yPosition += splitTaskText.length * 6 + 8;

            // Instructions with Service Now info
            const instructionText = `Please schedule a maintenance outage of at least two hours and contact the ITCC @ 918-732-4822 with service now ticket number [${ticket.serviceNowTicket || 'TBD'}] to coordinate Netops to apply security updates and reboot the equipment.`;
            const splitInstructionText = doc.splitTextToSize(instructionText, 170);
            doc.text(splitInstructionText, 20, yPosition);
            yPosition += splitInstructionText.length * 6 + 15;

            // Devices section
            doc.setFont('helvetica', 'bold');
            doc.text('The devices will be updated and rebooted in the following order:', 20, yPosition);
            yPosition += lineHeight + 5;

            doc.setFont('helvetica', 'normal');
            ticket.devices.forEach((device, index) => {
                doc.text(`${index + 1}. ${device}`, 30, yPosition);
                yPosition += lineHeight;
            });

            // Footer with additional details
            yPosition += 20;
            doc.setFontSize(10);
            doc.setTextColor(100, 100, 100);
            doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, yPosition);
            doc.text(`Supervisor: ${ticket.supervisor}`, 20, yPosition + 6);
            doc.text(`Tech: ${ticket.tech}`, 20, yPosition + 12);
            doc.text(`Status: ${ticket.status}`, 20, yPosition + 18);

            if (ticket.notes) {
                yPosition += 30;
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(12);
                doc.setTextColor(0, 0, 0);
                doc.text('Notes:', 20, yPosition);
                yPosition += 8;
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(10);
                const splitNotes = doc.splitTextToSize(ticket.notes, 170);
                doc.text(splitNotes, 20, yPosition);
            }

            // Generate base filename
            const siteName = ticket.location.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '');
            const dateStr = ticket.dateSubmitted.replace(/-/g, '');
            const ticketNum = ticket.hexagonTicket.replace(/[^a-zA-Z0-9]/g, '');
            const baseFilename = `${siteName}_${dateStr}_${ticketNum}`;

            // Add PDF to zip
            const pdfBlob = doc.output('blob');
            zip.file(`${baseFilename}.pdf`, pdfBlob);

            // Add shared documentation files (uploaded via "Attach Documentation")
            if (this.sharedDocumentation && this.sharedDocumentation.length > 0) {
                this.sharedDocumentation.forEach((doc_file, index) => {
                    // Convert base64 back to blob
                    const base64Data = doc_file.content.split(',')[1];
                    const binaryString = atob(base64Data);
                    const bytes = new Uint8Array(binaryString.length);
                    for (let i = 0; i < binaryString.length; i++) {
                        bytes[i] = binaryString.charCodeAt(i);
                    }
                    zip.file(doc_file.name, bytes);
                });
            }

            // Add attached files to zip
            if (ticket.attachments && ticket.attachments.length > 0) {
                ticket.attachments.forEach((attachment, index) => {
                    // Convert base64 back to blob
                    const base64Data = attachment.data.split(',')[1];
                    const binaryString = atob(base64Data);
                    const bytes = new Uint8Array(binaryString.length);
                    for (let i = 0; i < binaryString.length; i++) {
                        bytes[i] = binaryString.charCodeAt(i);
                    }
                    
                    // Rename file to match the base filename pattern
                    const fileExt = attachment.name.split('.').pop();
                    const newFileName = `${baseFilename}_attachment_${index + 1}.${fileExt}`;
                    
                    zip.file(newFileName, bytes);
                });
            }

            // Generate and download zip
            const zipBlob = await zip.generateAsync({type: 'blob'});
            const url = URL.createObjectURL(zipBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${baseFilename}_bundle.zip`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            this.showToast(`Bundle downloaded: ${baseFilename}_bundle.zip`, 'success');
        } catch (error) {
            console.error('Error creating bundle:', error);
            this.showToast('Error creating bundle', 'error');
        }
    }

    // Export Functions
    exportData(format) {
        const tickets = this.getFilteredTickets();
        
        if (tickets.length === 0) {
            this.showToast('No tickets to export', 'error');
            return;
        }

        switch (format) {
            case 'csv':
                this.exportCSV(tickets);
                break;
            case 'excel':
                this.exportExcel(tickets);
                break;
            case 'json':
                this.exportJSON(tickets);
                break;
            case 'pdf':
                this.exportPDF(tickets);
                break;
            case 'html':
                this.exportHTML(tickets);
                break;
        }
    }

    exportCSV(tickets) {
        const headers = ['Date Submitted', 'Date Due', 'Hexagon Ticket #', 'Service Now #', 'Location', 'Devices', 'Supervisor', 'Tech', 'Status', 'Notes'];
        const csvContent = [
            headers.join(','),
            ...tickets.map(ticket => [
                ticket.dateSubmitted,
                ticket.dateDue,
                `"${ticket.hexagonTicket}"`,
                `"${ticket.serviceNowTicket || ''}"`,
                `"${ticket.location}"`,
                `"${ticket.devices.join('; ')}"`,
                `"${ticket.supervisor}"`,
                `"${ticket.tech}"`,
                `"${ticket.status}"`,
                `"${ticket.notes || ''}"`
            ].join(','))
        ].join('\n');

        this.downloadFile(csvContent, 'hexagon-tickets.csv', 'text/csv');
    }

    exportExcel(tickets) {
        const ws = XLSX.utils.json_to_sheet(tickets.map(ticket => ({
            'Date Submitted': ticket.dateSubmitted,
            'Date Due': ticket.dateDue,
            'Hexagon Ticket #': ticket.hexagonTicket,
            'Service Now #': ticket.serviceNowTicket,
            'Location': ticket.location,
            'Devices': ticket.devices.join('; '),
            'Supervisor': ticket.supervisor,
            'Tech': ticket.tech,
            'Status': ticket.status,
            'Notes': ticket.notes || ''
        })));

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Hexagon Tickets');
        XLSX.writeFile(wb, 'hexagon-tickets.xlsx');
    }

    exportJSON(tickets) {
        const jsonContent = JSON.stringify(tickets, null, 2);
        this.downloadFile(jsonContent, 'hexagon-tickets.json', 'application/json');
    }

    exportPDF(tickets) {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF('l', 'mm', 'a4');

        doc.setFontSize(18);
        doc.text('Hexagon Tickets Report', 14, 22);
        
        doc.setFontSize(12);
        doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 32);
        doc.text(`Total Tickets: ${tickets.length}`, 14, 40);

        const tableData = tickets.map(ticket => [
            this.formatDate(ticket.dateSubmitted),
            this.formatDate(ticket.dateDue),
            ticket.hexagonTicket,
            ticket.serviceNowTicket || 'N/A',
            ticket.location,
            ticket.devices.join(', '),
            ticket.supervisor,
            ticket.tech,
            ticket.status
        ]);

        doc.autoTable({
            head: [['Date Submitted', 'Date Due', 'Hexagon #', 'Service Now #', 'Location', 'Devices', 'Supervisor', 'Tech', 'Status']],
            body: tableData,
            startY: 50,
            styles: { fontSize: 8 },
            columnStyles: {
                5: { cellWidth: 40 }
            }
        });

        doc.save('hexagon-tickets.pdf');
    }

    exportHTML(tickets) {
        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Hexagon Tickets Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .header { margin-bottom: 20px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Hexagon Tickets Report</h1>
                    <p>Generated on: ${new Date().toLocaleDateString()}</p>
                    <p>Total Tickets: ${tickets.length}</p>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Date Submitted</th>
                            <th>Date Due</th>
                            <th>Hexagon Ticket #</th>
                            <th>Service Now #</th>
                            <th>Location</th>
                            <th>Devices</th>
                            <th>Supervisor</th>
                            <th>Tech</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${tickets.map(ticket => `
                            <tr>
                                <td>${this.formatDate(ticket.dateSubmitted)}</td>
                                <td>${this.formatDate(ticket.dateDue)}</td>
                                <td>${ticket.hexagonTicket}</td>
                                <td>${ticket.serviceNowTicket || 'N/A'}</td>
                                <td>${ticket.location}</td>
                                <td>${ticket.devices.join(', ')}</td>
                                <td>${ticket.supervisor}</td>
                                <td>${ticket.tech}</td>
                                <td>${ticket.status}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </body>
            </html>
        `;

        this.downloadFile(htmlContent, 'hexagon-tickets.html', 'text/html');
    }

    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showToast(`${filename} downloaded successfully!`, 'success');
    }

    // Handle shared documentation upload
    async handleSharedDocumentation(files) {
        if (files.length === 0) return;

        this.sharedDocumentation = [];
        
        for (const file of files) {
            try {
                const base64Content = await this.fileToBase64(file);
                this.sharedDocumentation.push({
                    name: file.name,
                    type: file.type,
                    size: file.size,
                    content: base64Content
                });
            } catch (error) {
                console.error('Error processing shared documentation:', error);
                this.showToast(`Error uploading ${file.name}`, 'error');
            }
        }

        this.saveSharedDocumentation();
        this.showToast(`${files.length} documentation file(s) uploaded successfully!`, 'success');
    }

    // Save shared documentation to localStorage
    saveSharedDocumentation() {
        localStorage.setItem('hexagon_shared_docs', JSON.stringify(this.sharedDocumentation));
    }

    // Load shared documentation from localStorage
    loadSharedDocumentation() {
        const saved = localStorage.getItem('hexagon_shared_docs');
        if (saved) {
            this.sharedDocumentation = JSON.parse(saved);
        }
    }

    // View ticket in markdown format
    viewTicket(id) {
        const ticket = this.getTicketById(id);
        if (!ticket) {
            this.showToast('Ticket not found', 'error');
            return;
        }

        const markdown = this.generateMarkdown(ticket);
        document.getElementById('markdownContent').textContent = markdown;
        
        // Store current ticket ID for potential editing
        this.currentViewingId = id;
        
        const modal = new bootstrap.Modal(document.getElementById('viewTicketModal'));
        modal.show();
    }

    // Generate markdown format for ticket
    generateMarkdown(ticket) {
        let markdown = `# Hexagon Work Request\n\n`;
        
        markdown += `**Ticket Information:**\n`;
        markdown += `- Hexagon Ticket #: ${ticket.hexagonTicket || 'N/A'}\n`;
        markdown += `- ServiceNow Ticket #: ${ticket.serviceNowTicket || 'N/A'}\n`;
        markdown += `- Location: ${ticket.location || 'N/A'}\n`;
        markdown += `- Status: ${ticket.status || 'N/A'}\n\n`;
        
        markdown += `**Timeline:**\n`;
        markdown += `- Date Submitted: ${this.formatDate(ticket.dateSubmitted)}\n`;
        markdown += `- Required Completion Date: ${this.formatDate(ticket.dateDue)}\n\n`;
        
        markdown += `**Task Instruction:**\n`;
        markdown += `There are critical security patches that must be applied within 30 days at the [${ticket.location || 'SITE NAME'}] site.\n`;
        markdown += `Please schedule a maintenance outage of at least two hours and contact the ITCC @\n`;
        markdown += `918-732-4822 with service now ticket number [${ticket.serviceNowTicket || 'SERVICE NOW TICKET'}] to coordinate Netops to apply security\n`;
        markdown += `updates and reboot the equipment.\n\n`;
        
        if (ticket.devices && ticket.devices.length > 0) {
            markdown += `**Devices to be Updated:**\n`;
            markdown += `The following devices will be updated and rebooted:\n\n`;
            ticket.devices.forEach((device, index) => {
                markdown += `${index + 1}. ${device}\n`;
            });
            markdown += '\n';
        }

        markdown += `**Personnel:**\n`;
        markdown += `- Supervisor: ${ticket.supervisor || 'N/A'}\n`;
        markdown += `- Technician: ${ticket.tech || 'N/A'}\n\n`;

        if (ticket.notes && ticket.notes.trim()) {
            markdown += `**Additional Notes:**\n${ticket.notes}\n\n`;
        }

        markdown += `---\n`;
        markdown += `Generated: ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}\n`;

        return markdown;
    }

    // Copy markdown to clipboard
    copyMarkdownToClipboard() {
        const content = document.getElementById('markdownContent').textContent;
        navigator.clipboard.writeText(content).then(() => {
            this.showToast('Markdown copied to clipboard!', 'success');
        }).catch(err => {
            console.error('Failed to copy markdown:', err);
            this.showToast('Failed to copy markdown', 'error');
        });
    }

    // Edit ticket from view modal
    editTicketFromView() {
        const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewTicketModal'));
        viewModal.hide();
        
        setTimeout(() => {
            this.editTicket(this.currentViewingId);
        }, 300);
    }

    // Download bundle from view modal
    downloadBundleFromView() {
        this.bundleTicketFiles(this.currentViewingId);
    }

    // Handle CSV import
    async handleCsvImport(file) {
        if (!file) return;

        if (!file.name.toLowerCase().endsWith('.csv')) {
            this.showToast('Please select a CSV file', 'error');
            return;
        }

        try {
            const text = await file.text();
            const tickets = this.parseCsvToTickets(text);
            
            if (tickets.length === 0) {
                this.showToast('No valid tickets found in CSV file', 'warning');
                return;
            }

            // Replace existing tickets with imported tickets
            this.tickets = tickets;
            this.saveTickets();
            this.renderTickets();
            this.updateStatistics();
            this.populateLocationFilter();
            
            this.showToast(`Successfully imported ${tickets.length} ticket(s)! Previous data has been replaced.`, 'success');
        } catch (error) {
            console.error('Error importing CSV:', error);
            this.showToast('Error importing CSV file. Please check the format.', 'error');
        }
    }

    // Parse CSV text to tickets array
    parseCsvToTickets(csvText) {
        const lines = csvText.split('\n').filter(line => line.trim());
        if (lines.length < 2) return [];

        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const tickets = [];

        for (let i = 1; i < lines.length; i++) {
            const values = this.parseCsvLine(lines[i]);
            if (values.length === headers.length) {
                const ticket = {};
                
                headers.forEach((header, index) => {
                    let value = values[index].trim().replace(/"/g, '');
                    
                    // Map CSV headers to ticket properties
                    switch (header.toLowerCase()) {
                        case 'date submitted':
                        case 'datesubmitted':
                            ticket.dateSubmitted = value;
                            break;
                        case 'date due':
                        case 'datedue':
                            ticket.dateDue = value;
                            break;
                        case 'hexagon ticket':
                        case 'hexagon ticket #':
                        case 'hexagonticket':
                            ticket.hexagonTicket = value;
                            break;
                        case 'service now #':
                        case 'servicenow ticket':
                        case 'servicenow ticket #':
                        case 'servicenowticket':
                            ticket.serviceNowTicket = value;
                            break;
                        case 'location':
                        case 'site/group':
                            ticket.location = value;
                            break;
                        case 'devices':
                            ticket.devices = value ? value.split(';').map(d => d.trim()).filter(d => d) : [];
                            break;
                        case 'supervisor':
                            ticket.supervisor = value;
                            break;
                        case 'tech':
                        case 'technician':
                            ticket.tech = value;
                            break;
                        case 'status':
                            ticket.status = value;
                            break;
                        case 'notes':
                            ticket.notes = value;
                            break;
                    }
                });

                // Set defaults for missing fields
                ticket.dateSubmitted = ticket.dateSubmitted || new Date().toISOString().split('T')[0];
                ticket.dateDue = ticket.dateDue || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
                ticket.hexagonTicket = ticket.hexagonTicket || '';
                ticket.serviceNowTicket = ticket.serviceNowTicket || '';
                ticket.devices = ticket.devices || [];
                ticket.supervisor = ticket.supervisor || '';
                ticket.tech = ticket.tech || '';
                ticket.status = ticket.status || 'Open';
                ticket.notes = ticket.notes || '';

                // Generate ID and timestamps
                ticket.id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
                ticket.createdAt = new Date().toISOString();
                ticket.updatedAt = new Date().toISOString();

                // Only require location (consistent with form validation)
                if (ticket.location && ticket.location.trim()) {
                    tickets.push(ticket);
                } else {
                    console.log('Skipping ticket with missing location:', ticket);
                }
            }
        }

        return tickets;
    }

    // Parse CSV line handling quoted values
    parseCsvLine(line) {
        const values = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                values.push(current);
                current = '';
            } else {
                current += char;
            }
        }
        
        values.push(current);
        return values;
    }

    // Table sorting functionality
    sortTable(column) {
        // Update sort direction
        if (this.sortColumn === column) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortColumn = column;
            this.sortDirection = 'asc';
        }

        // Update header visual indicators
        this.updateSortHeaders();

        // Sort the tickets array
        this.tickets.sort((a, b) => {
            let valueA = a[column] || '';
            let valueB = b[column] || '';

            // Handle date columns
            if (column === 'dateSubmitted' || column === 'dateDue') {
                valueA = new Date(valueA);
                valueB = new Date(valueB);
            } else if (typeof valueA === 'string') {
                valueA = valueA.toLowerCase();
                valueB = valueB.toLowerCase();
            }

            let comparison = 0;
            if (valueA > valueB) {
                comparison = 1;
            } else if (valueA < valueB) {
                comparison = -1;
            }

            return this.sortDirection === 'desc' ? comparison * -1 : comparison;
        });

        // Re-render the table
        this.renderTickets();
    }

    updateSortHeaders() {
        // Remove all sort classes
        document.querySelectorAll('.sortable-header').forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
        });

        // Add appropriate class to current sort column
        if (this.sortColumn) {
            const header = document.querySelector(`[data-column="${this.sortColumn}"]`);
            if (header) {
                header.classList.add(this.sortDirection === 'asc' ? 'sort-asc' : 'sort-desc');
            }
        }
    }
}

// Global functions for button onclick events
let ticketManager;

function saveTicket() {
    ticketManager.saveTicket();
}

function editTicketFromView() {
    ticketManager.editTicketFromView();
}

function copyMarkdownToClipboard() {
    ticketManager.copyMarkdownToClipboard();
}

function downloadBundleFromView() {
    ticketManager.downloadBundleFromView();
}

function exportData(format) {
    ticketManager.exportData(format);
}

function sortTable(column) {
    ticketManager.sortTable(column);
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    ticketManager = new HexagonTicketsManager();
});
